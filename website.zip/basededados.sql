-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Apr 13, 2022 at 03:54 PM
-- Server version: 8.0.28-0ubuntu0.20.04.3
-- PHP Version: 7.4.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `basededados`
--

-- --------------------------------------------------------

--
-- Table structure for table `Acontecimentos`
--

CREATE TABLE `Acontecimentos` (
  `id` int NOT NULL,
  `requerente` varchar(90) DEFAULT NULL,
  `residente` varchar(80) DEFAULT NULL,
  `localobra` varchar(80) DEFAULT NULL,
  `tipoobra` varchar(80) DEFAULT NULL,
  `tecnico` varchar(50) DEFAULT NULL,
  `processo` int DEFAULT '0',
  `caixa` int DEFAULT '0',
  `entrada` varchar(20) DEFAULT NULL,
  `aprovacao` varchar(20) DEFAULT NULL,
  `licenca` varchar(90) DEFAULT NULL,
  `vistoria` varchar(80) DEFAULT NULL,
  `observacoes` varchar(50) DEFAULT NULL,
  `requerimento` varchar(50) DEFAULT NULL,
  `plantaLocal` varchar(50) DEFAULT NULL,
  `idUser` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `Acontecimentos`
--

INSERT INTO `Acontecimentos` (`id`, `requerente`, `residente`, `localobra`, `tipoobra`, `tecnico`, `processo`, `caixa`, `entrada`, `aprovacao`, `licenca`, `vistoria`, `observacoes`, `requerimento`, `plantaLocal`, `idUser`) VALUES
(6411, 'Alberto Afonso', 'Rua da Olivença - 10R/C - Castelo Branco', 'Rua Dr. Jaime Lopes Dias - Quinta do Amieiro de Cima - Castelo Branco ', 'Construção de uma casa de habitação', '', 286, 1, '09-06-1972', '12-07-1972', '481 26-08-1972', 'Licença de habitação nº218 de 20.02.1974', '', '', '', NULL),
(6412, 'Alberto Antunes', 'Rua do Mercado - 23 - Castelo Branco', 'Rua do Mercado  - 23 - Castelo Branco', 'Aditamento ao projecto de construção de uma casa', '', 205, 1, '12-05-1972', '21-06-1972', '413 - 18-07-1972', 'Licença de habitação nº 529 de 15-06-1974', '', '', '', NULL),
(6416, 'Alberto Trindade', 'Avenida Nuno Àlvares - Castelo Branco', 'Cadetes de Toledo - Castelo Branco', 'Colocação de andaimes na via publica', '', 1068, 1, '23-08-1971', '15-09-1971', '11 - 06-01-1972', '', '', '', '', NULL),
(6417, 'Adelino dos Santos', 'Bairro do Disco - Castelo Branco', 'Bairro do Disco - Castelo Branco', 'Informação sobre sobre se pode ampliar uma casa de habitação', '', 57, 1, '18-11-1971', '', '', '', '', '', '', NULL),
(6418, 'Alexandre Alves Roque', 'Lentiscais - Castelo Branco', 'Lentiscais - Castelo Branco', 'Construção de uma casa de habitação', '', 556, 1, '19-09-1972', '27-09-1972', '564 - 02-10-1972', '', '', '', '', NULL),
(6420, 'Amaro Minhós Ligeiro', 'Alcains', 'Gaveto formado pela Rua 5 de Outubro e Largo do Saibreiro - Castelo Branco', 'Construir um predio de rendimento', '', 19, 1, '17-01-1972', '23-02-1972', 'Licença de habitação nº 277 de 25-03-1974 e de ocupação nº 278 de 25-03-1974', '', '', '', '', NULL),
(6422, 'Americo Nunes Nogueira', 'Lentiscais - Castelo Branco', 'Rua da Fonte Santa - Lentiscais - Castelo Branco', 'Rebocar e caiar uma casa', '', 590, 2, '28-09-1972', '11-10-1972', '599 - 16-10-1972', '', '', '', '', NULL),
(6426, 'António Dias Diogo', 'Lentiscais - Castelo Branco', 'Lentiscais - Castelo Branco', 'Construção de uma cozinha', '', 690, 2, '04-11-1972', '08-02-1972', '685 - 20-11-1972', '', '', '', '', NULL),
(6427, 'António Dias dos Santos', 'Rua do Arressário - 44 - Castelo Branco', 'Rua do Arressário - 44 - Castelo Branco', 'Modificação de uma casa de habitação', '', 457, 2, '07-08-1972', '', '', '', '', '', '', NULL),
(6428, 'António Folgado Morais', 'Rua de Santa Maria -  35 - Castelo Branco', 'Rua do Arrabalde dos Açouges - 66 -  Castelo Branco', 'Construção de uma cozinha e casa de banho', '', 230, 2, '22-05-1972', '21-06-1972', '381 - 08-07-1972', '', '', '', '', NULL),
(6429, 'António Gonçalves Carneiro', 'Lentiscais - Castelo Branco', 'Lentiscais - Castelo Branco', 'Acabamentos de uma casa', '', 888, 2, '26-12-1972', '27-12-1972', '788 - 28-12-1972', '', '', '', '', NULL),
(6430, 'António Gonçalves Carneiro', 'Lentiscais - Castelo Branco', 'Rua da Atalaia - Lentiscais - Castelo Branco', 'Modificação de uma casa de habitação', '', 28, 2, '25-01-1972', '26-01-1972', '53/54 - 27-01-1972', '', '', '', '', NULL),
(6431, 'António Gonçalves Correia', 'Lentiscais - Castelo Branco', 'Lentiscais - Castelo Branco', 'Construção de um Palheiro', '', 577, 2, '25-09-1972', '27-09-1972', '588 - 12-10-1972', '', '', '', '', NULL),
(6432, 'António Hermenegildo', 'Travessa da Rua Nova - Castelo Branco', 'Travessa da Rua Nova - Castelo Branco', 'Modificação de uma casa de Habitação', '', 299, 2, '15-06-1972', '21-06-1972', '400 - 14-07-1972', '', '', '', '', NULL),
(6434, 'António Lucas Balhau', 'Escalos de Cima', 'Feiteira -  Castelo Branco', 'Solicitando Informação sobre o tipo de construção permitida', '', 26, 2, '04-07-1972', '', '', '', '', '', '', NULL),
(6435, 'António Luis de Oliveira Esteves', 'Rua Médico Henriques de Paiva - Castelo Branco', 'Rua Médico Henriques de Paiva - Castelo Branco', 'Modificação de uma casa de habitação', '', 395, 2, '18-07-1972', '16-08-1972', '582 - 09-10-1972', '', '', '', '', NULL),
(6436, 'António Maria Lopes Ferreira', 'Travessa do Relógio - 6  - 2º - Castelo Branco', 'Rua Afonso de Paiva -  Castelo Branco', 'Informação sobre os condicionamentos de ordem urbanistica', '', 8, 2, '26/02/1972', '', '', '', '', '', '', NULL),
(6437, 'António Moreira Cabrito', 'Lentiscais - Castelo Branco', 'Lentiscais - Castelo Branco', 'Construção de uma casa de habitação', '', 406, 2, '21-07-1972', '26/07/1972', '565 - 02-10-1972', '', '', '', '', NULL),
(6438, 'António Nunes Lourenço', 'Vilares de Cima - Sarzedas', 'Bairro do Barrocal  - Castelo Branco', 'Construção de um muro de vedação', '', 71, 2, '23-02-1972', '04-10-1972', '587 - 11-10-1972', '', '', '', '', NULL),
(6440, 'António de Oliveira Alves', 'Rua José Bento - 35 -  1º Esqº - Castelo Branco', 'Rua José Bento - 35 -  1º Esqº - Castelo Branco', 'Requer a construção de uma casa de banho', '', 1672, 2, '09-12-1972', '26-01-1972', '', '', '', '', '', NULL),
(6441, 'António Rodrigues Sebastião', 'Lentiscais - Castelo Branco', 'Lentiscais - Castelo Branco', 'Construção de um palheiro', '', 262, 2, '30-05-1972', '31-05-1972', '298 - 05-06-1972', '', '', '', '', NULL),
(6442, 'Banco de Portugal', 'Rua do Comércio - 14 B - Lisboa', 'Praça do Rei D. José I - Castelo Branco', 'Colocação de andaimes na via pública', '', 284, 2, '09-06-1972', '14-06-1972', '338 - 21-06-1972', '', '', '', '', NULL),
(6443, 'Caixa de Previdência e Abono de Família do Distrito de Castelo Branco', 'Rua do Rodrigo -  75 - Covilhã', 'Rua Eng. Frederico Ulrich - Castelo Branco', 'Beneficiação do Posto Médico de Castelo Branco', '', 2, 2, '17-05-1972', '', '', '', '', '', '', NULL),
(6444, 'Carlos Nobre Soares', 'Castelo Branco', 'Avenida Marechal Carmona  - Castelo Branco', 'Modificar a Fachada do seu estabelecimento', '', 430, 3, '29-11-1971', '17-12-1971', '290 - 30-05-1972', '', '', '', '', NULL),
(6449, 'Eduardo André', 'Arrabalde dos Oleiros - 71 - Castelo Branco', 'Arrabalde dos Açougues  - Castelo Branco', 'Solicitando informação sobre se pode ou não ampliar mais um piso', '', 23, 3, '30-05-1972', '14-06-1972', '', '', '', '', '', NULL),
(6450, 'Eduardo Lourenço', 'Castelo Branco', 'Rua de Arco do Bispo - 2 - 4 - Castelo Branco', 'Modificar a sua casa', '', 753, 3, '17-11-1972', '', '', '', '', '', '', NULL),
(6451, 'Eduardo Nogueira Cardoso', 'Rua Ruivo Godinho - 19 - Castelo Branco', 'Largo de São Marcos e Rua João de Deus - Castelo Branco', 'Colocação de andaimes na via publica e ocupação de 3 m da mesma', '', 216, 3, '17-05-1972', '24-05-1972', '316 - 08-06-1972', '', '', '', '', NULL),
(6452, 'Eduardo Nunes Barata', 'Rua Poeta João Roiz - 12  - 3º Dtº - Castelo Branco', 'Estrada do Montalvão Castelo Branco', 'solicitando informação sobre o tipo de construção permitido', '', 589, 3, '27-09-1972', '', '', '', '', '', '', NULL),
(6453, 'Faustino Monteiro de Figueiredo', 'Quinta do Amieiro de Cima - Castelo Branco', 'Quinta do Amieiro de Cima - Castelo Branco', 'Aproveitamento de umas casas em garagens', '', 206, 3, '13-05-1972', '', '', '', '', '', '', NULL),
(6454, 'Felicidade Catarina', 'Castelo Branco', 'Rua Eng. Frederico Ulrich - Castelo Branco', 'Modificação de primeira casa', '', 584, 3, '27-09-1972', '04/10/1972', '637 - 02-11-1972', '', '', '', '', NULL),
(6455, 'Felizardo Dias Gardete', 'Rua Diogo da Fonseca - Castelo Branco', 'Rua Eng. Frederico Ulrich  -13 - Castelo Branco', 'Informação se pode proceder à cobertura de um terreno', '', 62, 3, '29-12-1971', '12-01-1972', '', '', '', '', '', NULL),
(6456, 'Francisco Agostinho Monteiro', 'Rua Pedro da Fonseca  - 16 C - Castelo Branco', 'Rua Eng. Frederico Ulrich  -13 - Castelo Branco', 'Qual a construção tipo e numero de pisos', '', 40, 3, '04/11/1972', '12-12-1972', '', '', '', '', '', NULL),
(6457, 'Francisco Gonçalves Ribeiro', 'Paiágua - Almaceda', 'Rua Rodrigo Rebelo - 29 - Castelo Branco', 'Colocar andaimes na via publica', '', 213, 4, '16/05/1972', '16/05/1972', '293 - 16-05-1972', '', '', '', '', NULL),
(6458, 'João Carlos Cerqueira Correia e José Manuel do Couto Amaral Vicente', 'Castelo Branco', 'Largo do Municipio - Castelo Branco', 'Solicitando informação se pode construir um edificio com 3 pisos', '', 20, 3, '23/05/1972', '', '', '', '', '', '', NULL),
(6459, 'João de Matos Ferreira Romãozinho', 'Castelo Branco', 'Rua Conselheiro Alburquerque - Castelo Branco', 'Ampliação de mais um piso num predio de rendimento', '', 474, 3, '18/08/1972', '', '', '', '', '', '', NULL),
(6489, 'Jerónimo dos Reis', 'Castelo Branco', 'Rua do Vale do Cabreiro - Castelo Branco', 'Construir uma casa', '', 783, 7, '25-11-1972', '', '', '', '', '', '', NULL),
(6492, 'José António Bicho', 'Rua Diogo da Fonseca - 20  - 2º - Castelo Branco', 'Rua Pedro da Fonseca - Castelo Branco', 'Solicitando informação sobre as condições urbanisticas', '', 13, 7, '13-03-1972', '', '', '', '', '', '', NULL),
(6495, 'José Caetano', 'Largo de São João - Castelo Branco', 'Chão do Burro  - Castelo Branco', 'Construção de uma arrecadação', '', 308, 7, '19-06-1972', '21-07-1972', '363 - 03-07-1972', '', '', '', '', NULL),
(6496, 'José Cristóvão Vilela', 'Lentiscais - Castelo Branco', 'Lentiscais - Castelo Branco', 'Construção de uma casa de banho e de uma dispensa', '', 11, 7, '08-01-1972', '19-01-1972', '48 - 24-01-1972', '', '', '', '', NULL),
(6498, 'José Domingos Figueiredo', 'Quinta do Amieiro de Cima - Castelo Branco', 'Quinta do Amieiro de Cima - Castelo Branco', 'Colocação de andaimes na via publica', '', 293, 7, '13-06-1972', '14-06-1972', '415 - 19-07-1972', '', '', '', '', NULL),
(6502, 'José Lobo Carrilho', 'Travessa da Rua da Granja - Castelo Branco', 'Travessa da Rua da Granja - Castelo Branco', 'Informação sobre se pode ou não construir mais um piso numa cas de habitação', '', 16, 7, '10-04-1972', '26-04-1972', '', '', '', '', '', NULL),
(6503, 'José Maria Nunes', 'Lentiscais - Castelo Branco', 'Rua Nova - Lentiscais - Castelo Branco', 'Modificação de uma casa de habitação', '', 95, 7, '07-03-1972', '08-03-1972', '141 - 15-03-1972', '', '', '', '', NULL),
(6504, 'José Marques', 'Quinteiro - Castelo Branco', 'Quinteiro - Castelo Branco', 'Construção de uma casa de habitação', '', 21, 4, '18-01-1972', '', '', '', '', '', '', NULL),
(6505, 'José Marques Farias', 'Bairro do Disco - 11 A -Castelo Branco', 'Cortes - Castelo Branco', 'Solicitando declaração de viabilidade de construção de uma casa', '', 5, 4, '18-01-1972', '', '', '', '', '', '', NULL),
(6506, 'José Mantinho', 'Alameda Salazar, 16 - Castelo Branco', 'Alameda Salazar - 16 Castelo Branco', 'Colocar os andaimes na via publica', '', 423, 4, '25-07-1972', '', '', '', '', '', '', NULL),
(6507, 'José Mendes Cabrito e Outros', 'Castelo Branco', 'Rua Prof. Vieira de Almeida - Castelo Branco', 'Construção de uma Moradia', '', 412, 4, '21-07-1972', '16-08-1972', '494 - 04-09-1972', '', '', '', '', NULL),
(6508, 'José Moura Nunes da Cruz', 'Nisa', 'Rua dos Bombeiros Voluntários - Castelo Branco', 'Solicitando informação sobre se pode ampliar um piso numa casa de habitação', '', 9, 4, '29-02-1972', '', '', '', '', '', '', NULL),
(6510, 'José Pedro Dias', 'Rua Dadrá (Páteo do J. Valente) - Castelo Branco', 'Estrada do Chafariz Velho -  Castelo Branco', 'Informação sobre se pode ou não construir um andar numa casa de habitação', '', 29, 4, '22-07-1972', '', '', '', '', '', '', NULL),
(6511, 'José Pereira Lopes', 'Rua João Velho - 30 - Castelo Branco', 'Rua João Velho - 30 - Castelo Branco', 'Reconstrução e alteamento de uma casa de habitação', '', 100, 4, '08-03-1972', '29-03-1972', '279 - 23-05-1972', 'Licença de habitação nº 112 de 01-02-1973', '', '', '', NULL),
(6512, 'José Pereira Lopes', 'Rua João Velho - Castelo Branco', 'Rua João Velho - Castelo Branco', 'Ocupação de 5 m2 de via publica com materiais', '', 302, 4, '19-06-1972', '21-06-1972', '462 - 12-08-1972', '', '', '', '', NULL),
(6513, 'José Ramos Júnior e Manuel Luís Duarte', 'Rua do Vale Cabreiro - Castelo Branco', 'Rua do Vale Cabreiro - Castelo Branco', 'Construção de uma casa de Banho', '', 250, 5, '26-05-1972', '21-06-1972', '385 - 10-07-1972', '', '', '', '', NULL),
(6514, 'José dos Santos Calqueiro', 'Rua do Arressário - 33-35 - Castelo Branco', 'Rua do Arressário - 33 - 35 - Castelo Branco', 'Solicitando informação sobre o tipo de construção permitida', '', 34, 5, '26-08-1972', '', '', '', '', '', '', NULL),
(6515, 'José Luis Domingues Sebastião Santos', 'Vilar Barroco', 'Rua 5 de Outubro -  Castelo Branco', 'Informação sobre o tipo de construção', '', 23, 5, '14-06-1991', '', '', '', '', '', '', NULL),
(6516, 'José Sebastião', 'Castelo Branco', 'Rua de Santiago - Castelo Branco', 'Reclamação sobre obras em execução', '', 1275, 5, '05-09-1972', '', '', '', '', '', '', NULL),
(6517, 'José Vidal Sestay', 'Alameda Salazar - Castelo Branco', 'Alameda Salazar - Castelo Branco', 'Pintar a fachada de um pavilhão', '', 314, 5, '20-06-1972', '21-06-1972', '356 - 29-06-1972', '', '', '', '', NULL),
(6518, 'Júlio dos Santos Aguiar', 'Castelo Branco', 'Rua Dr. Rafeiro - Castelo Branco', 'Modificar uma casa', '', 678, 5, '02-11-1972', '02-11-1972', '684 - 02-11-1972', 'Licença de habitação nº 847 de 28-09-1973', '', '', '', NULL),
(6519, 'Leopoldo de Almeida Matos', 'Avenida Marechal Carmona - Castelo Branco', 'Estrada da Senhora de Mércules  - Castelo Branco', 'Solicitando info. Sobre o tipo de construção permitida', '', 33, 5, '18-08-1972', '', '', '', '', '', '', NULL),
(6520, 'Leopoldo de Almeida Matos', 'Avenida Marechal Carmona - Castelo Branco', 'Rua Padre Américo - Castelo Branco', 'Solicitando info. Sobre o tipo de construção permitida', '', 35, 5, '20-09-1972', '', '', '', '', '', '', NULL),
(6521, 'Luis Barreto', 'Lentiscais - Castelo Branco', 'Rua da Cruz Cimeira - Castelo Branco', 'Construção de uma Chaminé', '', 865, 5, '18-12-1972', '27-12-1972', '789 - 28-12-1972', '', '', '', '', NULL),
(6522, 'Luis Afonso Hormigo', 'Zona de Montalvão - Castelo Branco', 'Zona do Montalvão - Castelo Branco', 'Ampliação de uma fábrica de frigorificos', '', 249, 5, '26-05-1972', '12-07-1972', '398 - 13-07-1972', '', '', '', '', NULL),
(6523, 'Luis Freire Corte Real Gomes', 'Rua dos Bombeiros Voluntários - Castelo Branco', 'Rua dos Bombeiros Voluntários - Castelo Branco', 'Abertura de um portão num muro de vedação', '', 202, 5, '12-05-1972', '24-05-1972', '', '', '', '', '', NULL),
(6526, 'Manuel do Nascimento de Oliveira', 'Rua da Senhora de Mércules - 75 - Castelo Branco', 'Rua da Senhora de Mércules - 75 - Castelo Branco', 'Informação sobre se pode construir mais um piso numa casa de habitação', '', 22, 5, '04-06-1971', '', '', '', '', '', '', NULL),
(6528, 'Manuel Gonçalves', 'Rua do Matadouro -  10  - 1º - Castelo Branco', 'Cruz do Montalvão -  Castelo Branco', 'Solicitando info. Sobre se pode ou não construir uma casa com dois pisos', '', 37, 5, '12-10-1972', '', '', '', '', '', '', NULL),
(6530, 'Manuel Riscado Venâncio Leão', 'Gaveto das Ruas Dadrá e Rua Conselheiro Albuquerque - Castelo Branco', 'Gaveto das Ruas Dadrá e Conselheiro Albuquerque  - Castelo Branco', '', '', 1083, 5, '31-07-1972', '', ' - 02-08-1972', '', '', '', '', NULL),
(6532, 'Maria Emília Rego Gaspar', 'Castelo Branco', 'Rua de Santa Maria - 18 - Castelo Branco', 'Pintura de uma casa ocupação da via publica com andaimes', '', 582, 6, '27-09-1972', '', '', '', '', '', '', NULL),
(6533, 'Maria Joaquina Lopes Barreiros', 'Avenida Marechal Carmona - Castelo Branco', 'Avenida Marechal Carmona Castelo Branco', 'Modificar um casa de habitação', '', 336, 6, '27-06-1972', '05-07-1972', '', '', '', '', '', NULL),
(6535, 'Maria Lourenço', 'Rua Rei dos Mares -  38 - Castelo Branco', 'Rua Médico Sousa Refoios - Castelo Branco', 'Ampliação de uma casa de habitação', '', 500, 6, '23-08-1972', '', '', '', '', '', '', NULL),
(6536, 'Maria da Piedade Lopes Ferreira', 'Rua de São Sebastião - 19 - Castelo Branco', 'Travessa do Relogio -  8 -  Castelo Branco', 'Colocação de andaimes na via publica', '', 447, 6, '04-08-1972', '09-08-1972', '', '', '', '', '', NULL),
(6537, 'Maria Teresinha Domingos Reis Sanches e António de Azevedo Afonso', 'Quinta das Pedras - Lote 25 - Castelo Branco', 'Quinta das Pedras - Lote 25 - Castelo Branco', 'Construção de um predio de rendimento', '', 339, 6, '28-06-1972', '05-07-1972', '537 - 19-09-1972', 'Licença de habitação nº 1064 de 17-12-1973', '', '', '', NULL),
(6540, 'Moisés Nunes Martins', 'Rua dos Oleiros - 79 e 81 - Castelo Branco', 'Rua dos Oleiros  - 79 - 81 -  Castelo Branco', 'Solicitando info. Sobre se pode ou não construir terraço', '', 25, 6, '16-06-1972', '21-06-1972', '', '', '', '', '', NULL),
(6547, 'Teresa de Jesus Pires Amato Corte Real', 'Rua dos Bombeiros Voluntários - Castelo Branco', 'Rua dos Bombeiros Voluntários - Castelo Branco', 'solicitando informação se pode ampliar mais um piso numacas de habitação', '', 10, 6, '29-02-1972', '', '', '', '', '', '', NULL),
(6549, 'Vasco Luís Rodrigues da Conceição e Silva', 'Rua Príncipe Perfeito - Castelo Branco', 'Rua Príncipe Perfeito  - Castelo Branco', 'Modificação de uma casa de habitação', '', 332, 6, '27-06-1972', '05-07-1972', '515 - 13-09-1972', 'Licença de habitação nº 1336 de 17-11-1978', '', '', '', NULL),
(6552, 'Álvaro Pires Marques', 'Alcains', 'Construir uma casa de habitação', 'Construir uma moradia', '', 106, 1, '13-03-1972', '22-03-1972', '343 - 26-06-1972', '', '', '', '', NULL),
(6553, 'Ana do Céu Baltazar', 'Alcains', 'Alcains', 'Substituir os pavimentos de madeira por placas de betão armado', '', 160, 1, '19-04-1972', '26-04-1972', '248 - 05-05-1972', '', '', '', '', NULL),
(6556, 'Anibal Simões Gil', 'Alcains', 'Fonte Nova - Alcains', 'Construir uma casa de habitação', '', 182, 1, '17-06-1971', '', '', '', '', '', '', NULL),
(6557, 'Anibal Simões Gil', 'Alcains', 'Fonte Nova - Alcains', 'Construir uma moradia', '', 325, 1, '24-06-1972', '09-08-1972', '', '', '', '', '', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int NOT NULL,
  `username` varchar(10) NOT NULL,
  `password` varchar(300) DEFAULT NULL,
  `privilegios` varchar(10) DEFAULT '2'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `privilegios`) VALUES
(1, 'admin', '0192023a7bbd73250516f069df18b500', 'admin'),
(78, 'bruno', '25d55ad283aa400af464c76d713c07ad', 'ver/editar'),
(81, 'diogo', '25d55ad283aa400af464c76d713c07ad', 'ver/editar'),
(123, 'teste', '123', 'ver/editar'),
(124, 'teste2', '123', 'admin'),
(125, 'teste45', '202cb962ac59075b964b07152d234b70', 'admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Acontecimentos`
--
ALTER TABLE `Acontecimentos`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`),
  ADD UNIQUE KEY `id_2` (`id`),
  ADD KEY `idUser` (`idUser`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `Acontecimentos`
--
ALTER TABLE `Acontecimentos`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6706;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=126;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `Acontecimentos`
--
ALTER TABLE `Acontecimentos`
  ADD CONSTRAINT `Acontecimentos_ibfk_1` FOREIGN KEY (`idUser`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
