
<?php
include ('../con.php');
 
$username = $_POST['username'];
$password = md5($_POST['password']);
$priv = '';
$query = $db->query("Select * FROM users where username = '$username' and password ='$password'");
$query->execute();
$count = $query->rowcount();
$row = $query->fetch();

if ($count > 0)
	{
	 $resp = $query->fetch();
	 session_start();
         $_SESSION["id"] = $row['id'];
         $_SESSION["loggedin"] = true;
	 $_SESSION["privilegios"] = $priv;
         $_SESSION["username"] = $username;
         $_SESSION["password"] = md5($password);
       	 $query = $db->query("Select privilegios FROM users where username = '$username' and password ='$password'");        
	 $row = $query->fetch();
 	 $_SESSION["priv"] = $row['privilegios'];
}else{
$resp = 1;
}
print json_encode($resp);
?>
