<script type="text/javascript" src="inc/jquery.js"></script>
<script type="text/javascript" src="inc/bootstrap.min.js"></script>