<div class="container">
		<div class="row">
			<div class="col-lg-6 col-lg-offset-3">
				<p class="text-center text-muted" style="color: red">
			 <br>	@All Right Reserved By  Estagiarios da EST </br>
				</p>
			</div>
		</div>
	</div>
