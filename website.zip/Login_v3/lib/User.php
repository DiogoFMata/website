<?php
	include_once "lib/Session.php";
	include "lib/Database.php";
	class User{
		private $db;
		public function __construct(){
			$this->db = new Database();
		}
		public function userRegistration($data){
			$username = $data['username'];
			$username = filter_var($username, FILTER_SANITIZE_STRING, FILTER_FLAG_STRIP_HIGH);
			$password = $data['password'];
			$check_username = $this->checkusername($username);

			if (empty($username) || empty($password)) {
				$msg = "<div class='alert alert-danger'><strong>Erro !</strong>Os campos devem ser preenchidos !!</div>";
				return $msg;
			}
			if (strlen($username) < 3) {
				$msg = "<div class='alert alert-danger'><strong>Error !</strong>Username is too short !!</div>";
				return $msg;
			}elseif (preg_match('/[^a-z0-9_-]+/i', $username)) {
				$msg = "<div class='alert alert-danger'><strong>Error !</strong>Username only contains alphanuemaric,Dashed,Undescrore  !!</div>";
				return $msg;
			}
			$password = md5($data['password']);

			$sql = "INSERT INTO users (username,password) VALUES (:username,:password)";
			$query = $this->db->pdo->prepare($sql);
			$query->bindValue(':username',$username);
			$query->bindValue(':password',$password);
			$result = $query->execute();
			if ($result) {
				$msg = "<div class='alert alert-success'><strong>Successo !</strong> Registo efetuado com sucesso  !!</div>";
				return $msg;
			}else{
				$msg = "<div class='alert alert-danger'><strong>Erro !</strong>Something going wrong  !! Try agin Later.. </div>";
				return $msg;
			}
			}
		}
		public function checkusername($username){
			$sql 	= "SELECT username FROM users WHERE username= :username";
			$query = $this->db->pdo->prepare($sql);
			$query->bindValue(':username',$username);
			$query->execute();
			if ($query->rowCount() > 0) {
				return true;
				}else{
				return false;
			}
		}



	}
?>
