      margin: auto;
      transition: all 0.3s ease-in-out;
      background-color: #222;

      li a {
        font-size: 17px;
        padding: 0 5px;
      }
    }
  }
}

.active.parent {
  transform: translate(-40px, -25px);
  .link {
    font-size: 12px;

    .fa-minus {
      opacity: 1 !important;
      font-size: 8px;
    }

    .fa-plus {
      opacity: 0 !important;
    }
  }

  .subnavigation {
    display: flex;
  }
}

.active#clients {
  .subnavigation {
    transform: translate(-150px, 17px);
  }
}

.active#services {
  .subnavigation {
    transform: translate(-290px, 17px);
  }
}

.invisible {
  opacity: 0 !important;
  transform: translate(50px, 0);
}
