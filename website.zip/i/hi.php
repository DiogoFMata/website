<?php
session_start();
include('con.php');

if(isset($_POST['action']) && $_POST['action'] == "insert") {

    $c1 = $_POST['c1'];
    $c2 = $_POST['c2'];
    $c3 = $_POST['c3'];
    $c4 = $_POST['c4'];
    $c5 = $_POST['c5'];	
    $c6 = $_POST['c6'];
    $c7 = $_POST['c7'];
    $c8 = $_POST['c8'];
    $c9 = $_POST['c9'];
    $c10 = $_POST['c10'];
    $c11 = $_POST['c11'];
    $c12 = $_POST['c12'];
    $c13 = $_POST['c13'];
    $c14 = $_POST['c14'];


    $query = "INSERT INTO Acontecimentos (requerente, residente, localobra, tipoobra, tecnico, processo, caixa, entrada, aprovacao, licenca, vistoria, observacoes, requerimento, plantaLocal) VALUES (:c1, :c2, :c3, :c4, :c5, :c6, :c7, :c8, :c9, :c10, :c11, :c12, :c13, :c14)";
    $query_run = $db->prepare($query);

    $data = [
        ':c1' => $c1,
        ':c2' => $c2,
        ':c3' => $c3,
        ':c4' => $c4,
	':c5' => $c5,
 	':c6' => $c6,
 	':c7' => $c7,
 	':c8' => $c8,
	':c9' => $c9,
	':c10' => $c10,
	':c11' => $c11,
	':c12' => $c12,
	':c13' => $c13,
	':c14' => $c14,


    ];
    $query_execute = $query_run->execute($data);
header('Location: ../web/about.php');

}
?>
