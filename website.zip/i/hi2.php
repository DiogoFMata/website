<?php
session_start();
include('con.php');

if(isset($_POST['action']) && $_POST['action'] == "insert") {
    $c1 = $_POST['c1'];
    $c2 = md5($_POST['c2']);
    $c3 = $_POST['c3'];
    $c4 = md5($_POST['c4']);
    $query = "INSERT INTO users (username, password, privilegios) VALUES (:c1, :c2, :c3)";
    $query_run = $db->prepare($query);

    $data = [
        ':c1' => $c1,
        ':c2' => $c2,
        ':c3' => $c3,
    ];
    $query_execute = $query_run->execute($data);
header('Location: ../site/editar/services.php');
}else{
	echo "erro";
}
?>
