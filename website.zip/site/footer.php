  <footer>
      <div class="container">
        <div class="row">
          <div class="col-md-3 col-sm-6 col-xs-12">
            <div class="footer-item">
              <div class="footer-heading">
                <h2>Sobre nós</h2>
              </div>
              <p>Base de dados da Câmara Municipal de Castelo Branco. </p>
            </div>
          </div>
          <div class="col-md-3 col-sm-6 col-xs-12">
            <div class="footer-item">
              <div class="footer-heading">
                <h2>Mais informação</h2>
              </div>
              <ul class="footer-list">
                <li>Telefone: <a href="#">272 330 330</a></li>
                <li>Morada: <a href="https://goo.gl/maps/daG3cv8GGj91xwpq9">Praça do Município, 6000-458 Castelo Branco</a></li>
                <li>Site: <a href="https://www.cm-castelobranco.pt">https://www.cm-castelobranco.pt/</a></li>
              </ul>
            </div>
          </div>
          <div class="col-md-12">
            <div class="sub-footer">
              <p>Realizado por Estagiarios EST-RSI 2021/2022 </p>
            </div>
          </div>
        </div>
      </div>
   </footer>
