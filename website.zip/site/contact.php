<?php
// Inicialize a sessão
session_start();

// Verifique se o usuário está logado, caso contrário, redirecione para a página de login
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: /Login_v3/index.php");
    exit;
}
?>


<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="TemplateMo">
    <link href="https://fonts.googleapis.com/css?family=Roboto:100,300,400,500,700" rel="stylesheet">
    <link href="assets/scss/bootstrap.min.css" rel="stylesheet">
    <title>Atualizar Dados</title>
    <link rel="icon" type="image/png" sizes="32x32" href="./assets/images/favicon-32x32.png">
    <link rel="stylesheet" type="text/css" href="assets/sweetalert2/package/dist/sweetalert2.min.css">
    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Additional CSS Files -->
    <link rel="stylesheet" href="assets/css/fontawesome.css">
    <link rel="stylesheet" href="assets/css/templatemo-host-cloud.css">
    <link rel="stylesheet" href="assets/css/owl.css">
  </head>

  <body>

    <!-- ***** Preloader Start ***** -->
    <div id="preloader">
        <div class="jumper">
            <div></div>
            <div></div>
            <div></div>
        </div>
    </div>
    <!-- ***** Preloader End ***** -->
 <!-- Header -->
    <header class="">
      <nav class="navbar navbar-expand-lg">
        <div class="container">
          <a class="navbar-brand" href="index.php"><h2>Host <em>Cloud</em></h2></a>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarResponsive">
            <ul class="navbar-nav ml-auto">
              <li class="nav-item">
                <a class="nav-link" href="index.php">Home
                  <span class="sr-only">(current)</span>
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="about.php">Pesquisar Dados</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="editar/services.php">Gestão de utilizadores</a>
              </li>
            </ul>
          </div>
          <div class="functional-buttons">
            <ul>
              <li><a href="log.php">Log Out</a></li>
	      <li><a>Bem vindo <?php echo $_SESSION["username"]?></a></li>
            </ul>
          </div>
        </div>
      </nav>
    </header>
 <!-- Page Content -->
    <!-- Heading Starts Here -->
    <div class="page-heading header-text">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <h1>Contact Us</h1>
            <p><a href="index.php">Home</a> / <span>Contact Us</span></p>
          </div>
        </div>
      </div>
    </div>
    <!-- Heading Ends Here -->
 <div class="container">
        <div class="row">
            <div class="col-md-8 mt-4" style="margin-top:6%">

            <?php
            include './update/conupdate.php';
            ?>

           <div  class="card" style="margin-bottom: 25px;">
                <div class="card-header">
                        <h3 style="text-align=center"> Requerente nº:<?php echo $id?></h3>
                </div>
        <div class="card-body">

            <form method="POST" action="" id="update_cont">
                <div class="mb-3">
                        <input type="hidden" id="id" name="id" value="<?php echo $row['id']?>">
                </div>

		<div class="mb-3">
                    <label>Requerente</label>
                    <input class="form-control" id="requerente" type="text" value="<?php echo $row['requerente']?>" name="requerente"/>
                </div>
                <div class="mb-3">
                    <label>Residente</label>
                    <input class="form-control"  id="residente" type="text" value="<?php echo $row['residente']?>" name="residente"/>
                </div>
                <div class="mb-3">
                    <label>Local Obra</label>
                    <input class="form-control" id="localobra" type="text" value="<?php echo $row['localobra']?>" name="localobra"/>
                </div>
                <div class="mb-3">
                    <label>Tipo de Obra</label>
                    <input class="form-control" id="tipoobra" type="text" value="<?php echo $row['tipoobra']?>" name="tipoobra"/>
                </div>
                <div class="mb-3">
                    <label>Tecnico</label>
                    <input class="form-control" id="tecnico" type="text" value="<?php echo $row['tecnico']?>" name="tecnico"/>
                </div>

                <div class="mb-3">
                    <label>Processo</label>
                    <input class="form-control" id="processo" type="text" value="<?php echo $row['processo']?>" name="processo"/>
                </div>

                <div class="mb-3">
                    <label>Caixa</label>
                    <input class="form-control" id="caixa" type="text" value="<?php echo $row['caixa']?>" name="caixa"/>
                </div>
                <div class="mb-3">
                    <label>Entrada</label>
                    <input class="form-control"  id="entrada" type="text" value="<?php echo $row['entrada']?>" name="entrada"/>
                </div>
		  <div class="mb-3">
                    <label>Aprovação</label>
                    <input class="form-control"  id="aprovacao" type="text" value="<?php echo $row['aprovacao']?>" name="aprovacao"/>
                </div>

                <div class="mb-3">
                    <label>Licença</label>
                    <input class="form-control" id="licenca" type="text" value="<?php echo $row['licenca']?>" name="licenca"/>
                </div>

                 <div class="mb-3">
                    <label>Vistoria</label>
                    <input class="form-control" id="vistoria" type="text" value="<?php echo $row['vistoria']?>" name="vistoria"/>
                </div>

                <div class="mb-3">
                    <label>Observações</label>
                    <input class="form-control" id="observacoes" type="text" value="<?php echo $row['observacoes']?>" name="observacooes"/>
                </div>

                <div class="mb-3">
                    <label>Requerimento</label>
                    <input class="form-control" id="requerimento" type="text" value="<?php echo $row['requerimento']?>" name="requerimentos"/>
                </div>
                 <div class="mb-3">
                    <label>Planta Local</label>
                    <input class="form-control" id="plantaLocal" type="text" value="<?php echo $row['plantaLocal']?>" name="plantaLocal"/>
                </div>
                <div class="mb-3">
                    <button id="update_req" class="btn btn-primary" type="submit" name="update">Alterar Dados</button>
                </div>
            </form>
        </div>
       </div>
      </div>
    </div>
  </div>
<?php
	include 'footer.php';
?>
 <!-- Bootstrap core JavaScript -->
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/sweetalert2/package/dist/sweetalert2.min.js"></script>    
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="java.php"></script>

    <!-- Additional Scripts -->
    <script src="assets/js/custom.js"></script>
    <script src="assets/js/owl.js"></script>
    <script src="assets/js/accordions.js"></script>


    <script language = "text/Javascript">
      cleared[0] = cleared[1] = cleared[2] = 0; //set a cleared flag for each field
      function clearField(t){                   //declaring the array outside of the
      if(! cleared[t.id]){                      // function makes it static and global
          cleared[t.id] = 1;  // you could use true and false, but that's more typing
          t.value='';         // with more chance of typos
          t.style.color='#fff';
          }
      }
    </script>

  </body>
</html>



