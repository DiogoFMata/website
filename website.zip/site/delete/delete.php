
<?php
	if(ISSET($_GET['id'])){
		require_once '../../con.php';
		$id = $_GET['id'];
		$query = $db->prepare("DELETE from `Acontecimentos` WHERE `id`='$id'");
		$query->execute();
                $wp=$query;

header('Location: ../about.php');
 }
?>
