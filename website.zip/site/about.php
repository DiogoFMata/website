<?php
// Inicialize a sessão
session_start();

// 	Verifique se o usuário está logado, se não, redirecione-o para uma página de login
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: /Login_v3/index.php");
    exit;
}
?>


<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <link href="https://fonts.googleapis.com/css?family=Roboto:100,300,400,500,700" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <script src="assets/jquery.min.js" type="text/javascript"></script>
    <script src="assets/DatePick/js/bootstrap-datepicker.min.js" charset="utf-8" type="text/javascript"></script>
    <link rel="stylesheet" href="assets/DatePick/css/bootstrap-datepicker.css">
    <script src="assets/DatePick/locales/bootstrap-datepicker.pt-BR.min.js"></script>
    <title>Pesquisar Dados</title>
     <link rel="icon" type="image/png" sizes="32x32" href="./assets/images/favicon-32x32.png">

        <link rel="stylesheet" type="text/css" href="assets/sweetalert2/package/dist/sweetalert2.min.css">
    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
	<!-- Additional CSS Files -->
    <link rel="stylesheet" href="assets/css/fontawesome.css">
    <link rel="stylesheet" href="assets/css/templatemo-host-cloud.css">
    <link rel="stylesheet" href="assets/css/owl.css">
    <link rel="stylesheet" href="est1.css">
  </head>

  <body>

    <!-- ***** Preloader Start ***** -->
    <div id="preloader">
        <div class="jumper">
            <div></div>
            <div></div>
            <div></div>
        </div>
    </div>  
    <!-- ***** Preloader End ***** -->

    <!-- Header -->
    <header class="">
      <nav class="navbar navbar-expand-lg">
        <div class="container">
          <a class="navbar-brand" href="index.php"><h2>Base <em>dados</em></h2></a>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarResponsive">
            <ul class="navbar-nav ml-auto">
              <li class="nav-item">
                <a class="nav-link" href="index.php">Home
                  <span class="sr-only">(current)</span>
                </a>
              </li>
              <li class="nav-item active">
                <a class="nav-link" href="about.php">Pesquisar dados</a>
              </li>
  	<?php
		if($_SESSION["priv"]=="admin"){
	?>
 		<li class="nav-item">
                <a class="nav-link" href="editar/services.php">Gestão de utilizadores</a>
              </li>
            </ul>
        <?php
	}else{
	}
	?>
	 </div>
          <div class="functional-buttons">
            <ul>
              <li><a href="./logout/log.php">Log Out</a></li>
              <li><a>Bem vindo <?php echo $_SESSION["username"]?></a></li>
            </ul>
          </div>
        </div>
      </nav>
    </header>

    <!-- Page Content -->
    <!-- Heading Starts Here -->
    <div class="page-heading header-text">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
		<br><br><br><br>   
         <h1 style="color:black"> Pesquisar dados</h1>
          </div>
        </div> </div>
    </div>
    <!-- Heading Ends Here -->
<div  class="container">
   <div  class="row">
         <div  class="col-md-8 col-md-offset-2" style="margin-top: 6%; margin-left:2%">
                 <div  class="row">
<?php
                        include '../con.php';
                        if(isset($_GET['search'])){
                         $searchKey = $_GET['search'];
                         $sql = "SELECT * FROM Acontecimentos WHERE id LIKE '%$searchKey%'";
                       }else if(isset($_GET['search1'])){
                         $searchKey = $_GET['search1'];
                         $sql = "SELECT * FROM Acontecimentos WHERE requerente LIKE '%$searchKey%'";
                       }else if(isset($_GET['search2'])){
                         $searchKey = $_GET['search2'];
                         $sql = "SELECT * FROM Acontecimentos WHERE processo LIKE '%$searchKey%'";
                       }else
                         $sql = "SELECT * FROM Acontecimentos";
                         $query = $db->query($sql);
?>
<table class="table table-bordered text-left" style="margin-top: -2%; background:white">
<body>
<tr>
<p1 style="margin-left: -73px;">Procurar por ID<p1>
                <form action="" method="GET" text-align="right">
                        <div class="col-md-6">
                                <input type="text" name="search" placeholder="Procurar por ID" value=<?php echo @$_GET['search']; ?> >
                        </div>
                        <div class="col-md-6">
                                <button class="btn">Procurar</button>
                        </div>
                </form>
        <p2>Procurar por Nome<p2>
                <form action="" method="GET">
                        <div class="col-md-6">
                                <input type="text" name="search1"  placeholder="Procurar por Nome" value=<?php echo @$_GET['search1']?>>
                         </div>
                        <div class="col-md-6">
                                <button class="btn">Procurar</button>
                        </div>
                </form>
        </p2>
        <p3>Procurar por Processo<p3>
                <form action="" method="GET">
                        <div class="col-md-6">
                                <input type="text" name="search2"  placeholder="Procurar por Processo" value=<?php echo @$_GET['search2']?>>
                        </div>
                        <div class="col-md-6">
                                <button class="btn">Procurar</button> <br>	
<form>
		        </div>
<?php
if($_SESSION["priv"]=="admin" || $_SESSION["priv"]=="ver/editar"){
?>

                 		<div class="col-lg-6" style="margin-left: 34px; margin-top: -41px;">
<br><br>
                                <button type="button" class="btn btn-primary m-1 float-right" data-toggle="modal" data-target="#addModal"><i class="fa fa-plus" aria-hidden="true"></i>&nbsp;&nbsp;Adicionar Dados</button>
                        </div>
<?php
}
?>
                </form>
 <br>
  <br>
</table>    
<!-- Add New User Modal -->
  <div class="modal fade" id="addModal">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content" style="margin-top: 71px;">

        <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-title">Adicionar Requerimento</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>

        <!-- Modal body -->
        <div class="modal-body px-4">
          <form action="" method="POST" id="form-data">
                           <div class="form-group">
                                <input type="text" name="c1" class="form-control" placeholder="Requerente" required/>
                            </div>
                            <div class="form-group">
                                <input type="text" name="c2" class="form-control" placeholder="Residente" required/>
                            </div>
                            <div class="form-group">
                                <input type="text" name="c3" class="form-control" placeholder="Local da Obra" required/>
                            </div>
                            <div class="form-group">
                                <input type="text" name="c4" class="form-control" placeholder="Tipo de Obra"required/>
                            </div>
                            <div class="form-group">
                                <input type="text" name="c5" class="form-control" placeholder="Técnico"/>
                            </div>
                            <div class="form-group">
                                <input type="text" name="c6" class="form-control" placeholder="Processo"required/>
                            </div>
                            <div class="form-group">
                                <input type="text" name="c7" class="form-control" placeholder="Caixa" />
                            </div>
				<div class="form-group">
				  <div class="input-group date fj-date">
                                 <input type="text" name="c8" class="form-control" placeholder="Entrada - Data(dd-mm-aaaa)" required><span class="input-group-addon"><i class="glyphicon glyphicon-th"></i></span>                           
                                 </div>
				</div>
                            <div class="form-group">
				<div class="input-group date fj-date">
                                <input type="text" name="c9" class="form-control" placeholder="Aprovação - Data(dd-mm-aaaa)"/><span class="input-group-addon"><i class="glyphicon glyphicon-th"></i></span> 
				</div>		                    
                            </div>
                            <div class="form-group">
                                <input type="text" name="c10" class="form-control" placeholder="Licença - (numero-dd-mm-aaaa)"/>
                            </div>
                            <div class="form-group">
                                <input type="text" name="c11" class="form-control" placeholder="Vistoria"/>
                            </div>
                            <div class="form-group">
                                <input type="text" name="c12" class="form-control" placeholder="Observações" />
                            </div>
                            <div class="form-group">
                                <input type="text" name="c13" class="form-control" placeholder="Requerimento"/>
                            </div>
                            <div class="form-group">
                                <input type="text" name="c14" class="form-control" placeholder="Planta do Local"/>
                            </div>
                             <div class="form-group">
                                 <input type="submit" name="insert" id="insert" value="Adicionar Dados" class="btn btn-success">
                             </div>
           </form>
       </div>
      </div>
    </div>
  </div>
<!-- View User Modal --!>
<div id="dataModal" class="modal fade">
 <div class="modal-dialog">
  <div class="modal-content"style="width: 163%; margin-top: 93px;">
   <div class="modal-header">
 <h4 class="modal-title" style="text-align=center">Restantes Dados</h4>

    <button type="button" class="close" data-dismiss="modal">×</button>
   </div>
   <div class="modal-body" id="employee_detail">
     
   </div>
   <div class="modal-footer">
    <button type="button" class="btn btn-default" data-dismiss="modal">Fechar</button>
   </div>
  </div>
 </div>
</div>
<!-- End View User Modal --!>

<table class="table table-bordered text-left"  style="margin-top: 6%; margin-left: auto; margin-right: auto; background:white;">
<thead>
<tr>

<th>IdCliente</th>
<th>Requerente</th>
<th>Residente</th>
<th>Local da Obra</th>
<th>Tipo de Obra</th>
<th>Ver Mais</th>
<?php
if($_SESSION["priv"]=="admin" || $_SESSION["priv"]=="ver/editar"){
?>

<th>Editar</th>
<th>Eliminar</th>
<?php
}else{
}
?>
</thead>
<tbody>
<?php while($row = $query->fetch(PDO::FETCH_ASSOC)) : ?>
<div>
  <tr>
       <td><?php echo htmlspecialchars($row['id']); ?></td>
       <td><?php echo htmlspecialchars($row['requerente']); ?></td>
       <td><?php echo htmlspecialchars($row['residente']); ?></td>
       <td><?php echo htmlspecialchars($row['localobra']); ?></td>
       <td><?php echo htmlspecialchars($row['tipoobra']); ?></td>
       <td><button id="<?php echo $row['id'];?>" class="btn btn-info btn-xs view_data"><i class="fa fa-eye" aria-hidden="true" style="color:black"></i> Ver</button></td>
<?php
if($_SESSION["priv"]=="admin" || $_SESSION["priv"]=="ver/editar"){
?>
<td><a href="./contact.php?id=<?php echo $row['id'];?>"><button  class="btn" style="background-color: orange"><i class="fa-solid fa-pen-to-square"></i> Editar </button></a></td>
<td><a href="./delete/delete.php?id=<?php echo $row['id'];?>"><button class="btn del-btn" style="background-color:#ff000094"><i class="fa-solid fa-delete-left"></i> Eliminar </button></a></td>
<?php
}else{
}
?>
 </tr>
  <?php endwhile; ?>
</table>
</div>
</div>
</div>
</div>

 <!-- Footer Starts Here -->
<?php
include 'footer.php'
?>

    <!-- Footer Ends Here -->

    <!-- Bootstrap core JavaScript -->
  <script type="text/javascript">
            $('.fj-date').datepicker({
		format: "dd/mm/yyyy",
		language: "pt-BR"
        });
    </script>
<script src="vendor/jquery/jquery.js"></script>
        <script src="vendor/bootstrap/js/bootstrap.min.js"></script>
        <script src="assets/sweetalert2/package/dist/sweetalert2.min.js"></script>
        <script src="java.php"></script>
        <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Additional Scripts -->
    <script src="assets/js/custom.js"></script>
    <script src="assets/js/owl.js"></script>
    <script src="assets/js/accordions.js"></script>

    <script language = "text/Javascript"> 
      cleared[0] = cleared[1] = cleared[2] = 0; //set a cleared flag for each field
      function clearField(t){                   //declaring the array outside of the
      if(! cleared[t.id]){                      // function makes it static and global
          cleared[t.id] = 1;  // you could use true and false, but that's more typing
          t.value='';         // with more chance of typos
          t.style.color='#fff';
          }
      }
    </script>

  </body>
</html>
