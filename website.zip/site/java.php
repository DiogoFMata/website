         src="vendor/jquery/jquery.js"
         src="vendor/bootstrap/js/bootstrap.min.js"
         src="assets/sweetalert2/package/dist/sweetalert2.min.js"
         src="vendor/bootstrap/js/bootstrap.bundle.min.js"
//Botão Delete
 $('.del-btn').on('click',function(e){
            e.preventDefault();
const href = $(this).parent().attr('href')
            Swal.fire({
                title: 'Tem a certeza de deseja eliminar as informações referente a este requerente?',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Sim, exclua!'
                }).then((result) => {
                    if (result.value) {
			  Swal.fire(
    				  'Eliminado!',
				 'As informações foram eliminidas com succeso!',
     				 'success'
 			 ).then((result) =>{
                                                if(result.value){
                                                        window.location.href = href;
                                                }


                                        })
                    }
                })
         })

//Botão Insert Dados
  $("#insert").click(function(e) {
        if($("#form-data")[0].checkValidity()) {
          e.preventDefault();
          $.ajax({
            url: "../i/hi.php",
            type: "POST",
            data: $("#form-data").serialize() + "&action=insert",
            success: function(response) {
              Swal.fire({
                title: 'Dados Inseridos com Sucesso!',
                icon: 'success'
              })
              $("#addModal").modal('hide');
              $("#form-data")[0].reset();
              showAllUsers();
            }
          });
        }
      });
//Botão Login
$("#formLogin").submit(function(e){
        e.preventDefault();
        var username = $.trim($("#username").val());
        var password = $.trim($("#password").val());

        if(username == "" || password == ""){
                Swal.fire({
                        icon : 'warning',
                        title : 'Deve inserir as credenciais todas!'

        });
        return false;
        }else{
                $.ajax({
                        url:"../Login_v3/a.php",
                        type:"POST",
                        datatype:"json",
                        data:{username:username, password:password},
                        success:function(resp){
                                if (resp == 1){
                                        Swal.fire({
                                                icon:'error',
                                                title:'Nome ou password inválidos!',
                                        });
                                }else{
                                        Swal.fire({
                                                        icon:'success',
                                                        title:'Login bem sucedido!',
                                                        confirmButtonColor:'#3085d6',
                                                        confirmButtonText:'Entrar'
                                        }).then((result) =>{
                                                if(result.value){
                                                window.location.href = "../site/index.php";
						 }


                                        })
                                }
                        }
                });
        }


});
//Botão View
 $(document).on('click', '.view_data', function(){
  //$('#dataModal').modal();
  var employee_id = $(this).attr("id");
  $.ajax({
   url:"view/select.php",
   method:"POST",
   data:{employee_id:employee_id},
   success:function(data){
    $('#employee_detail').html(data);
    $('#dataModal').modal('show');
   }
  });
 });
//botao Edit User
  $("#u_update").click(function(e) {
        if($("#update")[0].checkValidity()) {
        e.preventDefault();
          var c2 = $.trim($("#c2").val());
          var c4 = $.trim($("#c4").val());
          var c5 = $.trim($("#c5").val());
        if(c2 != c4){
                Swal.fire({
                        icon:'warning',
                        title:'As passwords não coincidem',
                        confirmButtonColor:'#3085d6',
                        confirmButtonText:'Tentar Novamente'
                });

        }else if(c2.length < 5){
                Swal.fire({
                        icon:'error',
                        title:'Tamanho da password inválido',
                        confirmButtonColor:'#3085d6',
                        confirmButtonText:'Tentar Novamente'
                });
        }else{
                e.preventDefault();
                Swal.fire({
                        title: 'Tem a certeza de deseja alterar as informações referente a este utilizador?',
                        icon: 'info',
                        showCancelButton: true,
                        confirmButtonColor: '#3085d6',
                        cancelButtonColor: '#d33',
                        confirmButtonText: 'Sim, alterar!'
                }).then((result) => {
                 if (result.value) {
                         $.ajax({
                                url: "update4.php",
                                type: "POST",
                                data: $("#update").serialize() + "&action=update",
                                success: function(response) {
                                        Swal.fire({
                                                icon:'success',
                                                title:'Dados alterados com sucesso!',
                                                confirmButtonColor:'#3085d6',
                                                confirmButtonText:'Voltar'
                                        }).then((result) =>{
                                                if(result.value){
                                                        window.location.href = "services.php";
                                                 }


                        })
                        }
                });
                        }else{
                Swal.fire({
                        title: 'Dados não alterados',
                        icon: 'info'
                })
        }
                })
                }
         }
});
//Botao Editar Requerente (contact.php)
 $("#update_req").click(function(e) {
        if($("#update_cont")[0].checkValidity()) {
        e.preventDefault();
          var c1 = $.trim($("#requerente").val());
          var c2 = $.trim($("#residente").val());
          var c3 = $.trim($("#localobra").val());
	  var c4 = $.trim($("#tipoobra").val());
          var c5 = $.trim($("#processo").val());
	  var c6 = $.trim($("#entrada").val());        
        
      if(c6 =="" || c1 =="" || c2 =="" || c3 =="" || c4 =="" || c5 ==""){
                Swal.fire({
                        icon:'warning',
                        title:'Existem campos obrigatórios por preencher!',
                        confirmButtonColor:'#3085d6',
                        confirmButtonText:'Tentar Novamente'
                });

        
       }else{
                e.preventDefault();
                Swal.fire({
                        title: 'Tem a certeza de deseja alterar as informações referente a este requerente?',
                        icon: 'info',
                        showCancelButton: true,
                        confirmButtonColor: '#3085d6',
                        cancelButtonColor: '#d33',
                        confirmButtonText: 'Sim, alterar!'
                }).then((result) => {
                 if (result.value) {
                         $.ajax({
                                url: "./update/update1.php",
                                type: "POST",
                                data: $("#update").serialize() + "&action=update_req",
                                success: function(response) {
                                        Swal.fire({
                                                icon:'success',
                                                title:'Dados alterados com sucesso!',
                                                confirmButtonColor:'#3085d6',
                                                confirmButtonText:'Voltar'
                                        }).then((result) =>{
                                                if(result.value){
                                                        window.location.href = "about.php";
                                                 }


                        })
                        }
                });
                        }else{
                Swal.fire({
                        title: 'Dados não alterados',
                        icon: 'info'
                })
        }
                })
                }
         }
});

