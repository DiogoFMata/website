<?php  
//select.php  
if(isset($_POST["employee_id"]))
{
include ('../../con.php');
$query = $db->query("SELECT * FROM Acontecimentos WHERE id = '".$_POST["employee_id"]."'");
?>

<!DOCTYPE html>
<html lang="en">

<table class="table table-bordered text-left" style="margin-top: 6%; background:white">
<thead>
<tr>

<th>Técnico</th>
<th>Processo</th>
<th>Caixa</th>
<th>Entrada</th>
<th>Aprovação</th>
<th>Licença</th>
<th>Vistoria</th>
<th>Observações</th>
<th>Planta Local</th>
</thead>
<tbody>
<?php while($row = $query->fetch(PDO::FETCH_ASSOC)) : ?>
<div>
  <tr>
       <td><?php echo htmlspecialchars($row['tecnico']); ?></td>
       <td><?php echo htmlspecialchars($row['processo']); ?></td>
       <td><?php echo htmlspecialchars($row['caixa']); ?></td>
       <td><?php echo htmlspecialchars($row['entrada']); ?></td>
       <td><?php echo htmlspecialchars($row['aprovacao']); ?></td>
       <td><?php echo htmlspecialchars($row['licenca']); ?></td>
       <td><?php echo htmlspecialchars($row['vistoria']); ?></td>
       <td><?php echo htmlspecialchars($row['observacoes']); ?></td>
       <td><?php echo htmlspecialchars($row['plantaLocal']); ?></td>
</tr>
  <?php endwhile; ?>
</table>
<?php
}
?>
</html>

