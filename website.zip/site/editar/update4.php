<?php
if(isset($_POST['action']) && $_POST['action'] == "update") {
    require_once '../../con.php';
            $c1 = $_POST['c1'];
            $c2 = $_POST['c2'];
            $c3 = $_POST['c3'];
            $c4 = $_POST['c4'];
	    $c5 = $_POST['c5'];
            $sql = "UPDATE users SET username = '$c1', password = '$c2', privilegios = '$c3' WHERE id = '$c5'";
            $db->exec($sql);
 header('Location: services.php');
}else{
 echo "2";
}
?>
