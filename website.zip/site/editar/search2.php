<?php
   if(isset($_GET['id'])){
                require_once '../../con.php';
                $id = $_GET['id'];
                $query = $db->prepare("SELECT * FROM users WHERE id ='$id'");
                $query->execute();
		$row = $query->fetch();
	}
?>
