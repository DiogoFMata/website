<?php
// Inicialize a sessão
session_start();
// Verifique se o usuário está logado, caso contrário, redirecione para a página de login
if(!isset($_SESSION["loggedin"]) || ($_SESSION["loggedin"]) !== true || $_SESSION["priv"] != "admin"){
    header("location: ../../Login_v3/index.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">

  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="TemplateMo">
    <link href="https://fonts.googleapis.com/css?family=Roboto:100,300,400,500,700" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../assets/scss/bootstrap.min.css" rel="stylesheet">
    <title>Base de dados - Gestão de utilizadores</title>
    <link rel="stylesheet" type="text/css" href="../assets/sweetalert2/package/dist/sweetalert2.min.css">

    <!-- Bootstrap core CSS -->
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Additional CSS Files -->
    <link rel="stylesheet" href="../assets/css/fontawesome.css">
    <link rel="stylesheet" href="../assets/css/templatemo-host-cloud.css">
    <link rel="stylesheet" href="../assets/css/owl.css">
  </head>

  <body>

    <!-- ***** Preloader Start ***** -->
    <div id="preloader">
        <div class="jumper">
            <div></div>
            <div></div>
            <div></div>
        </div>
    </div>
    <!-- ***** Preloader End ***** -->

    <!-- Header -->
    <header class="">
      <nav class="navbar navbar-expand-lg">
        <div class="container">
          <a class="navbar-brand" href="../index.php"><h2>Base <em>dados</em></h2></a>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarResponsive">
            <ul class="navbar-nav ml-auto">
              <li class="nav-item">
                <a class="nav-link" href="../index.php">Home
                  <span class="sr-only">(current)</span>
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="../about.php">Pesquisar Dados</a>
              </li>
              <li class="nav-item active">
                <a class="nav-link" href="../editar/services.php">Gestão de Utilizadores</a>
              </li>
            </ul>
          </div>
          <div class="functional-buttons">
            <ul>
              <li>
		<a href="../logout/log.php">Log Out</a>
		</li>
             	 <li>
		<a> Bem Vindo <?php echo $_SESSION['username']?></a>
		</li>
            </ul>
          </div>
        </div>
      </nav>
    </header>

    <!-- Page Content -->
    <!-- Heading Starts Here -->
  <!-- Heading Starts Here -->
     <div class="page-heading header-text"> 
     <div class="container">
        <div class="row">
          <div class="col-md-12">
	<br><br><br><br>
            <h1 style="color:black" >Gestão de utilizadores</h1>
          </div>
        </div>
      </div>
     </div>  
  <!-- Heading Ends Here -->
      

    <!-- Heading Ends Here -->

<!-- Add New User Modal -->
 <div class="col-lg-6" style="margin-left: 470px; margin-top: -15px;">
<br><br>
                                <button type="button" class="btn btn-primary m-1 float-right" data-toggle="modal" data-target="#addModal"><i class="fa fa-plus" aria-hidden="true"></i>&nbsp;&nbsp;Adicionar Utilizador</button>
                        </div>
<!-- Add New User Modal -->
  <div class="modal fade" id="addModal">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content" style="margin-top: 71px;">

        <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-title">Adicionar Utilizador</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>

        <!-- Modal body -->
        <div class="modal-body px-4">
          <form action="" method="POST" id="form-data">
                           <div class="form-group">
                                <input type="text" id="c1" name="c1" class="form-control" placeholder="Utilizador" required/>
                            </div>
                            <div class="form-group">
                                <input type="password" id="c2" name="c2" class="form-control" placeholder="Password" required/>
                            </div>
                            <div class="form-group">
                                <input type="password" id="c4" name="c4" class="form-control" placeholder="Confirmar Password" required/>
                            </div>
			    <div class="form-group">
                                <input type="radio" id="c3" name="c3" value="admin"/> Admin
                            </div>
			    <div class="form-group">
                                <input type="radio" id="c3" name="c3" value="ver/editar" /> Ver/Editar
                            </div>
			    <div class="form-group">
                                <input type="radio" id="c3" name="c3" value="ver" checked="check" /> Ver
                            </div>
			    <div class="form-group">
                                 <input type="submit" name="insert" id="insert" value="Adicionar Dados" class="btn btn btn-success">
                             </div>

   </form>
       </div>
      </div>
    </div>
  </div>
<table class="table table-bordered text-left" style="margin-top: 6%; margin-left: auto; margin-right: auto; background:white;">
<thead>
<tr>

<th>Id</th>
<th>Username</th>
<th>Privilegios</th>
<th>Editar</th>
<th>Eliminar</th>
</thead>
<tbody>

<?php
require_once 'Search.php';
 while($row = $sql->fetch(PDO::FETCH_ASSOC)) : ?>

<div>
  <tr>
       <td><?php echo htmlspecialchars($row['id']); ?></td>
       <td><?php echo htmlspecialchars($row['username']); ?></td>
       <td><?php echo htmlspecialchars($row['privilegios']); ?></td>

<td><a href="edit_user.php?id=<?php echo $row['id'];?>"><button  class="btn" style="background-color: orange"><i class="fa-solid fa-pen-to-square"></i> Editar </button></a></td>

<td><a href="delete.php?id=<?php echo $row['id'];?>"><button class="btn del-btn" style="background-color:#ff000094"><i class="fa-solid fa-delete-left"></i> Eliminar </button></a></td>

</tr>
<?php endwhile; ?>

     <!-- Bootstrap core JavaScript -->
        <script src="../vendor/jquery/jquery.js"></script>
        <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>
        <script src="../assets/sweetalert2/package/dist/sweetalert2.min.js"></script>
        <script src="../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
        <script src="java3.php"></script>



    <!-- Additional Scripts -->
    <script src="../assets/js/custom.js"></script>
    <script src="../assets/js/owl.js"></script>
    <script src="../assets/js/accordions.js"></script>

    <script language = "text/Javascript"> 
      cleared[0] = cleared[1] = cleared[2] = 0; //set a cleared flag for each field
      function clearField(t){                   //declaring the array outside of the
      if(! cleared[t.id]){                      // function makes it static and global
          cleared[t.id] = 1;  // you could use true and false, but that's more typing
          t.value='';         // with more chance of typos
          t.style.color='#fff';
          }
      }
    </script>


  </body>
</html>
