<?php
                    require_once '../../con.php';
                    $sql = $db->prepare("SELECT * FROM users");
                    $sql->execute();
                    $row = $sql->fetch();
?>
