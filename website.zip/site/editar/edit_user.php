<?php
// Inicialize a sessão
session_start();

// Verifique se o usuário está logado, caso contrário, redirecione para a página de login
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true|| $_SESSION["priv"] != "admin"){
    header("location: ../../Login_v3/index.php");
    exit;
}
?>


<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="TemplateMo">
    <link href="https://fonts.googleapis.com/css?family=Roboto:100,300,400,500,700" rel="stylesheet">
    <link href="../assets/scss/bootstrap.min.css" rel="stylesheet">
   <link rel="stylesheet" type="text/css" href="../assets/sweetalert2/package/dist/sweetalert2.min.css">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../assets/scss/bootstrap.min.css" rel="stylesheet">  
 <title>Atualizar Dados</title>
    <link rel="icon" type="image/png" sizes="32x32" href="../assets/images/favicon-32x32.png">

    <!-- Bootstrap core CSS -->
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Additional CSS Files -->
    <link rel="stylesheet" href="../assets/css/fontawesome.css">
    <link rel="stylesheet" href="../assets/css/templatemo-host-cloud.css">
    <link rel="stylesheet" href="../assets/css/owl.css">
  </head>

  <body>

    <!-- ***** Preloader Start ***** -->
    <div id="preloader">
        <div class="jumper">
            <div></div>
            <div></div>
            <div></div>
        </div>
    </div>
    <!-- ***** Preloader End ***** -->
 <!-- Header -->
    <header class="">
      <nav class="navbar navbar-expand-lg">
        <div class="container">
          <a class="navbar-brand" href="index.php"><h2>Base <em>dados</em></h2></a>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarResponsive">
            <ul class="navbar-nav ml-auto">
              <li class="nav-item">
                <a class="nav-link" href="../index.php">Home
                  <span class="sr-only">(current)</span>
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="../about.php">Pesquisar Dados</a>
              </li>
              <li class="nav-item active">
                <a class="nav-link" href="services.php">Gestão de utilizadores</a>
 </li>
            </ul>
          </div>
          <div class="functional-buttons">
            <ul>
              <li><a href="../log.php">Log Out</a></li>
              <li><a>Bem vindo <?php echo $_SESSION["username"]?></a></li>
           </ul>
          </div>
        </div>
      </nav>
    </header>
 <!-- Page Content -->
    <!-- Heading Starts Here -->
    <div class="page-heading header-text">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <h1 style="color:black">Editar Utilizador</h1>
            <p><a href="../index.php">Home</a> </p>
          </div>
        </div>
      </div>
    </div>
    <!-- Heading Ends Here -->
 <div class="container">
        <div class="row">
            <div class="col-md-8 mt-4" style="margin-top:6%">

            <?php
            include 'search2.php';
            ?>

           <div  class="card" style="margin-bottom: 25px;">
        <div class="card-body">

            <form method="POST" action="" id ="update">
		<div class="mb-3">
			<input type="hidden" id="c5" name="c5" value="<?php echo $row['id']?>">
		</div>
               <div class="mb-3">
                    <input class="form-control" type="text" value="<?php echo $row['username']?>" id="c1" name="c1" required/>
                </div>
                <div class="mb-3">
                    <input class="form-control" type="password"  id="c2" name="c2" placeholder="Password" required/>
                </div>
		<div>
		    <input class="form-control" type="password" id="c4" name="c4" placeholder="Confirmar password" required>
		</div>
                <div class="mb-3">
                <div class="form-group">
                   <input type="radio" id="c3" name="c3" value="admin"/> Admin
                 </div>
                 <div class="form-group">
                  <input type="radio" id="c3" name="c3" value="ver/editar" /> Ver/Editar
                  </div>
                  <div class="form-group">
                   <input type="radio" id="c3" name="c3" value="ver" checked="check" /> Ver
                   </div>
		    </div>
                 <div class="mb-3">
                   <button id="u_update" class="btn btn-primary" type="submit" name="update" >Alterar Dados</button>
                </div>
            </form>
        </div>
       </div>
      </div>
    </div>
  </div>
<?php
        include '../footer.php';
?>
 <!-- Bootstrap core JavaScript -->
    <script src="../vendor/jquery/jquery.min.js"></script>
    <script src="../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="../vendor/jquery/jquery.js"></script>
        <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>
        <script src="../assets/sweetalert2/package/dist/sweetalert2.min.js"></script>
        <script src="../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Additional Scripts -->
    <script src="../assets/js/custom.js"></script>
    <script src="../assets/js/owl.js"></script>
    <script src="../assets/js/accordions.js"></script>
<script src="java3.php"></script>   
 <script language = "text/Javascript">
      cleared[0] = cleared[1] = cleared[2] = 0; //set a cleared flag for each field
      function clearField(t){                   //declaring the array outside of the
      if(! cleared[t.id]){                      // function makes it static and global
          cleared[t.id] = 1;  // you could use true and false, but that's more typing
          t.value='';         // with more chance of typos
          t.style.color='#fff';
          }
      }
    </script>
  </body>
</html>

