<?php
    require_once '../../con.php';
 
if(isset($_POST['action']) && $_POST['action'] == "update_req") {
           
            $id = $_POST['id'];
            $requerente = $_POST['requerente'];
            $residente = $_POST['residente'];
            $localobra = $_POST['localobra'];
            $tipoobra = $_POST['tipoobra'];
	    $tecnico = $_POST['tecnico'];
	    $processo = $_POST['processo'];
	    $caixa = $_POST['caixa'];
            $entrada = $_POST['entrada'];
            $aprovacao = $_POST['aprovacao'];
	    $licenca = $_POST['licenca'];
	    $vistoria =  $_POST['vistoria'];
            $observacoes  =$_POST['observacoes'];
	    $requerimento = $_POST['requerimento'];
	    $plantaLocal =$_POST['plantaLocal'];

            $sql = "UPDATE Acontecimentos SET requerente = '$requerente', residente = '$residente', localobra = '$localobra', tipoobra = '$tipoobra', tecnico = '$tecnico', processo = '$processo', caixa = '$caixa', entrada = '$entrada', aprovacao = '$aprovacao', licenca = '$licenca', vistoria = '$vistoria', observacoes = '$observacoes', requerimento = '$requerimento', plantaLocal = '$plantaLocal' WHERE id = '$id'";   
            $db->exec($sql);
  	    $msg= $db->exec($sql);
	header('Location: ../about.php');

    }
?>
