<?php
                if(isset($_GET['id'])){
                    require_once '../con.php';
                    $id = $_GET['id'];
                    $sql = $db->prepare("SELECT * FROM Acontecimentos WHERE id = '$id'");
                    $sql->execute();
                    $row = $sql->fetch();
                }
?>
