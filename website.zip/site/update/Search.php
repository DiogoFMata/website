<?php
                if(isset($_POST['id'])){
                    require_once '../con.php';
                    $id = $_POST['id'];
                    $sql = $db->prepare("SELECT * FROM Acontecimentos WHERE id = '$id'");
                    $sql->execute();
                    $row = $sql->fetch();
                }
?>
